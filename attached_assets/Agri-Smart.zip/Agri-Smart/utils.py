import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

def load_data():

    try:
        df = pd.read_csv('attached_assets/Updated_Crop_Recommendation.csv')
        return df
    except Exception as e:
        raise Exception(f"Error loading dataset: {str(e)}")

def preprocess_data(df):
    features = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
    X = df[features]
    y = df['label']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    return X_train_scaled, y_train, scaler

def train_model(X, y):
    try:
        model = KNeighborsClassifier(n_neighbors=5, weights='distance')
        model.fit(X, y)
        return model
    except Exception as e:
        raise Exception(f"Error training model: {str(e)}")

def get_recommendation(model, scaler, input_data):
    try:
        if input_data.shape[0] != 7:
            raise ValueError("Invalid input data shape")

        input_scaled = scaler.transform(input_data.reshape(1, -1))

        prediction = model.predict(input_scaled)
        probabilities = model.predict_proba(input_scaled)

        top_3_idx = np.argsort(probabilities[0])[-3:][::-1]
        recommendations = [
            (model.classes_[idx], probabilities[0][idx]) 
            for idx in top_3_idx
        ]

        return recommendations
    except Exception as e:
        raise Exception(f"Error getting recommendation: {str(e)}")

def get_crop_statistics(df):
    try:
        stats = {
            'total_crops': len(df['label'].unique()),
            'avg_success_rate': (df[~df['Disease_Prone']].shape[0] / df.shape[0] * 100),
            'common_diseases': df['Common_Disease'].value_counts().to_dict(),
            'optimal_conditions': {
                crop: {
                    'temperature': {
                        'mean': df[df['label'] == crop]['temperature'].mean(),
                        'range': [
                            df[df['label'] == crop]['temperature'].min(),
                            df[df['label'] == crop]['temperature'].max()
                        ]
                    },
                    'humidity': {
                        'mean': df[df['label'] == crop]['humidity'].mean(),
                        'range': [
                            df[df['label'] == crop]['humidity'].min(),
                            df[df['label'] == crop]['humidity'].max()
                        ]
                    },
                    'ph': {
                        'mean': df[df['label'] == crop]['ph'].mean(),
                        'range': [
                            df[df['label'] == crop]['ph'].min(),
                            df[df['label'] == crop]['ph'].max()
                        ]
                    },
                    'rainfall': {
                        'mean': df[df['label'] == crop]['rainfall'].mean(),
                        'range': [
                            df[df['label'] == crop]['rainfall'].min(),
                            df[df['label'] == crop]['rainfall'].max()
                        ]
                    }
                }
                for crop in df['label'].unique()
            }
        }
        return stats
    except Exception as e:
        raise Exception(f"Error calculating statistics: {str(e)}")