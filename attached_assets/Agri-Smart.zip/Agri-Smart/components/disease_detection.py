import streamlit as st
import numpy as np
from PIL import Image
import io
from components.model_handler import load_model, predict_disease

DISEASE_DATABASE = {
    "Apple_scab": {
        "description": "A fungal disease causing dark, scabby lesions on leaves, fruit, and twigs.",
        "causes": [
            "Fungal pathogen (Venturia inaequalis)",
            "Cool, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Prune to improve air circulation",
            "Remove and destroy infected leaves and fruit"
        ]
    },
    "Black_spot": {
        "description": "A fungal disease causing black spots on leaves and stems.",
        "causes": [
            "Fungal pathogen (Diplocarpon rosae)",
            "High humidity",
            "Poor air circulation"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected leaves",
            "Improve air circulation"
        ]
    },
    "Tomato_late_blight": {
        "description": "A disease causing dark, water-soaked lesions on leaves, stems, and fruit.",
        "causes": [
            "Oomycete pathogen (Phytophthora infestans)",
            "Cool, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected plants",
            "Avoid overhead watering"
        ]
    },
    "Tomato_early_blight": {
        "description": "A disease causing concentric rings on leaves and fruit.",
        "causes": [
            "Fungal pathogen (Alternaria solani)",
            "Warm, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Rotate crops",
            "Remove and destroy infected plant debris"
        ]
    },
    "Corn_common_rust": {
        "description": "A fungal disease causing reddish-brown pustules on leaves.",
        "causes": [
            "Fungal pathogen (Puccinia sorghi)",
            "Cool, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Plant resistant varieties",
            "Rotate crops"
        ]
    },
    "Potato_late_blight": {
        "description": "A disease causing dark, water-soaked lesions on leaves, stems, and tubers.",
        "causes": [
            "Oomycete pathogen (Phytophthora infestans)",
            "Cool, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected plants",
            "Avoid overhead watering"
        ]
    },
    "Strawberry_leaf_scorch": {
        "description": "A fungal disease causing dark, V-shaped lesions on leaf edges.",
        "causes": [
            "Fungal pathogen (Diplocarpon earlianum)",
            "Wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected leaves",
            "Improve air circulation"
        ]
    },
    "Apple_black_rot": {
        "description": "A fungal disease causing black, sunken lesions on fruit and leaves.",
        "causes": [
            "Fungal pathogen (Botryosphaeria obtusa)",
            "Warm, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Prune to remove infected branches",
            "Remove and destroy infected fruit"
        ]
    },
    "Apple_cedar_apple_rust": {
        "description": "A fungal disease causing yellow-orange spots on leaves and fruit.",
        "causes": [
            "Fungal pathogen (Gymnosporangium juniperi-virginianae)",
            "Proximity to cedar trees"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove nearby cedar trees",
            "Plant resistant varieties"
        ]
    },
    "Healthy": {
        "description": "No disease detected. Your plant appears to be healthy.",
        "causes": [],
        "remedies": []
    },
    "Powdery_Mildew": {
        "description": "White, powdery fungal growth on leaves and stems.",
        "causes": [
            "Fungal spores",
            "High humidity",
            "Poor air circulation"
        ],
        "remedies": [
            "Apply sulfur-based fungicides",
            "Increase plant spacing",
            "Prune to improve air flow",
            "Water at base of plants"
        ]
    },
    "Downy_Mildew": {
        "description": "A disease causing yellow to white patches on the upper leaf surface.",
        "causes": [
            "Oomycete pathogen",
            "Cool, moist conditions"
        ],
        "remedies": [
            "Apply fungicides",
            "Improve air circulation",
            "Avoid overhead watering"
        ]
    },
    "Leaf_Rust": {
        "description": "A fungal disease causing orange to yellow pustules on leaves.",
        "causes": [
            "Fungal pathogen",
            "High humidity"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected leaves",
            "Improve air circulation"
        ]
    },
    "Stem_Rust": {
        "description": "A fungal disease causing reddish-brown pustules on stems and leaves.",
        "causes": [
            "Fungal pathogen",
            "High humidity"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected plant parts",
            "Improve air circulation"
        ]
    },
    "Fusarium_Wilt": {
        "description": "A soil-borne fungal disease causing wilting and yellowing of leaves.",
        "causes": [
            "Fungal pathogen (Fusarium oxysporum)",
            "Warm soil temperatures"
        ],
        "remedies": [
            "Use resistant varieties",
            "Rotate crops",
            "Improve soil drainage"
        ]
    },
    "Sclerotinia": {
        "description": "A fungal disease causing white mold on stems, leaves, and pods.",
        "causes": [
            "Fungal pathogen (Sclerotinia sclerotiorum)",
            "Cool, wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected plant parts",
            "Improve air circulation"
        ]
    },
    "Leaf_Spot": {
        "description": "A fungal disease causing small, dark spots on leaves.",
        "causes": [
            "Fungal pathogen",
            "Wet weather"
        ],
        "remedies": [
            "Apply fungicides",
            "Remove and destroy infected leaves",
            "Improve air circulation"
        ]
    },
    "Seedling_Damping_Off": {
        "description": "A disease causing seedlings to rot at the soil line and collapse.",
        "causes": [
            "Soil-borne pathogens",
            "Overwatering",
            "Poor soil drainage"
        ],
        "remedies": [
            "Use sterile soil",
            "Avoid overwatering",
            "Improve soil drainage"
        ]
    },
    "Bacterial_Wilt": {
        "description": "A bacterial disease causing rapid wilting and death of plants.",
        "causes": [
            "Ralstonia solanacearum bacteria",
            "Warm temperatures",
            "High soil moisture"
        ],
        "remedies": [
            "Use resistant varieties",
            "Practice crop rotation",
            "Improve soil drainage",
            "Sterilize tools and equipment"
        ]
    },
    "Bacterial_Blight": {
        "description": "A bacterial disease causing water-soaked lesions on leaves and stems.",
        "causes": [
            "Bacterial pathogen",
            "Wet weather"
        ],
        "remedies": [
            "Apply copper-based bactericides",
            "Remove and destroy infected plant parts",
            "Improve air circulation"
        ]
    },
    "Fire_Blight": {
        "description": "A bacterial disease causing blackened, wilted leaves and branches.",
        "causes": [
            "Bacterial pathogen (Erwinia amylovora)",
            "Warm, wet weather"
        ],
        "remedies": [
            "Prune to remove infected branches",
            "Apply copper-based bactericides",
            "Avoid overhead watering"
        ]
    },
    "Crown_Gall": {
        "description": "A bacterial disease causing tumor-like growths on roots and stems.",
        "causes": [
            "Bacterial pathogen (Agrobacterium tumefaciens)",
            "Wounds on plant"
        ],
        "remedies": [
            "Remove and destroy infected plants",
            "Avoid wounding plants",
            "Use disease-free planting material"
        ]
    },
    "Tobacco_Mosaic_Virus": {
        "description": "A viral disease causing mosaic patterns on leaves.",
        "causes": [
            "Tobacco mosaic virus",
            "Infected plant material"
        ],
        "remedies": [
            "Remove and destroy infected plants",
            "Disinfect tools",
            "Use resistant varieties"
        ]
    },
    "Tomato_Spotted_Wilt_Virus": {
        "description": "A viral disease causing necrotic spots on leaves and fruit.",
        "causes": [
            "Tomato spotted wilt virus",
            "Thrips vectors"
        ],
        "remedies": [
            "Control thrips",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Tomato_Yellow_Leaf_Curl_Virus": {
        "description": "A viral disease causing yellowing and curling of leaves.",
        "causes": [
            "Tomato yellow leaf curl virus",
            "Whitefly vectors"
        ],
        "remedies": [
            "Control whiteflies",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Cucumber_Mosaic_Virus": {
        "description": "A viral disease causing mosaic patterns on leaves and fruit.",
        "causes": [
            "Cucumber mosaic virus",
            "Aphid vectors"
        ],
        "remedies": [
            "Control aphids",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Potato_Virus_Y": {
        "description": "A viral disease causing mosaic patterns and leaf crinkling.",
        "causes": [
            "Potato virus Y",
            "Aphid vectors"
        ],
        "remedies": [
            "Control aphids",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Cauliflower_Mosaic_Virus": {
        "description": "A viral disease causing mosaic patterns on leaves.",
        "causes": [
            "Cauliflower mosaic virus",
            "Aphid vectors"
        ],
        "remedies": [
            "Control aphids",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "African_Cassava_Mosaic_Virus": {
        "description": "A viral disease causing mosaic patterns on cassava leaves.",
        "causes": [
            "African cassava mosaic virus",
            "Whitefly vectors"
        ],
        "remedies": [
            "Control whiteflies",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Plum_Pox_Virus": {
        "description": "A viral disease causing chlorotic rings on leaves and fruit.",
        "causes": [
            "Plum pox virus",
            "Aphid vectors"
        ],
        "remedies": [
            "Control aphids",
            "Remove and destroy infected plants",
            "Use resistant varieties"
        ]
    },
    "Brome_Mosaic_Virus": {
        "description": "A viral disease causing mosaic patterns on leaves.",
        "causes": [
            "Brome mosaic virus",
            "Infected plant material"
        ],
        "remedies": [
            "Remove and destroy infected plants",
            "Disinfect tools",
            "Use resistant varieties"
        ]
    },
    "Potato_Virus_X": {
        "description": "A viral disease causing mild mosaic patterns on leaves.",
        "causes": [
            "Potato virus X",
            "Infected plant material"
        ],
        "remedies": [
            "Remove and destroy infected plants",
            "Disinfect tools",
            "Use resistant varieties"
        ]
    }
}

def preprocess_image(image):
    image = image.resize((224, 224))
    image_array = np.array(image)
    return image_array

def render_disease_detection():
    st.title("🔍 Crop Disease Detection")
    
    st.markdown("""
        <div class="stat-card">
            <h3>Upload an image of your crop to detect diseases</h3>
            <p>For best results:</p>
            <ul>
                <li>Ensure good lighting</li>
                <li>Focus on the affected area</li>
                <li>Use clear, high-resolution images</li>
            </ul>
        </div>
    """, unsafe_allow_html=True)

    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        try:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", use_column_width=True)

            with st.spinner("Analyzing image..."):
                model = load_model()
                
                preprocessed_image = preprocess_image(image)
                
                prediction = predict_disease(model, preprocessed_image)
                detected_disease = prediction["disease"]
                confidence = prediction["confidence"]

            st.success("Analysis Complete!")
            
            col1, col2 = st.columns([1, 2])
            
            with col1:
                st.markdown(f"""
                    <div class="stat-card">
                        <h3>Detection Results</h3>
                        <p>Detected Disease: <strong>{detected_disease}</strong></p>
                        <p>Confidence: <strong>{confidence:.1%}</strong></p>
                    </div>
                """, unsafe_allow_html=True)

            with col2:
                disease_info = DISEASE_DATABASE.get(detected_disease, {})
                st.markdown(f"""
                    <div class="stat-card">
                        <h3>Disease Information</h3>
                        <p><strong>Description:</strong> {disease_info.get('description', 'N/A')}</p>
                        <p><strong>Common Causes:</strong></p>
                        <ul>
                            {''.join(f'<li>{cause}</li>' for cause in disease_info.get('causes', []))}
                        </ul>
                        <p><strong>Recommended Remedies:</strong></p>
                        <ul>
                            {''.join(f'<li>{remedy}</li>' for remedy in disease_info.get('remedies', []))}
                        </ul>
                    </div>
                """, unsafe_allow_html=True)

        except Exception as e:
            st.error(f"Error processing image: {str(e)}")
            st.error("Please try uploading a different image.")

if __name__ == "__main__":
    render_disease_detection()