import streamlit as st
import numpy as np
import pandas as pd
from utils import get_recommendation

def validate_input(nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall):
    if not (0 <= nitrogen <= 140):
        return False, "Nitrogen should be between 0 and 140 mg/kg"
    if not (0 <= phosphorus <= 140):
        return False, "Phosphorus should be between 0 and 140 mg/kg"
    if not (0 <= potassium <= 200):
        return False, "Potassium should be between 0 and 200 mg/kg"
    if not (0 <= temperature <= 50):
        return False, "Temperature should be between 0 and 50°C"
    if not (0 <= humidity <= 100):
        return False, "Humidity should be between 0 and 100%"
    if not (0 <= ph <= 14):
        return False, "pH should be between 0 and 14"
    if not (0 <= rainfall <= 300):
        return False, "Rainfall should be between 0 and 300mm"
    return True, ""

def render_recommendation_form(model, scaler):
    st.title("🌱 Crop Recommendation")

    with st.form("recommendation_form"):
        col1, col2 = st.columns(2)

        with col1:
            nitrogen = st.number_input("Nitrogen (N) mg/kg", 0, 140, 50,
                                     help="Amount of nitrogen in soil (0-140 mg/kg)")
            phosphorus = st.number_input("Phosphorus (P) mg/kg", 0, 140, 50,
                                       help="Amount of phosphorus in soil (0-140 mg/kg)")
            potassium = st.number_input("Potassium (K) mg/kg", 0, 200, 50,
                                      help="Amount of potassium in soil (0-200 mg/kg)")
            temperature = st.number_input("Temperature (°C)", 0.0, 50.0, 25.0,
                                        help="Average temperature (0-50°C)")

        with col2:
            humidity = st.number_input("Humidity (%)", 0.0, 100.0, 50.0,
                                     help="Relative humidity (0-100%)")
            ph = st.number_input("pH", 0.0, 14.0, 7.0,
                               help="Soil pH level (0-14)")
            rainfall = st.number_input("Rainfall (mm)", 0.0, 300.0, 100.0,
                                     help="Annual rainfall in millimeters (0-300mm)")

        submitted = st.form_submit_button("Get Recommendation")

        if submitted:
            try:
                is_valid, error_message = validate_input(
                    nitrogen, phosphorus, potassium, temperature, 
                    humidity, ph, rainfall
                )

                if not is_valid:
                    st.error(error_message)
                    return

                input_data = np.array([nitrogen, phosphorus, potassium, 
                                   temperature, humidity, ph, rainfall])

                recommendations = get_recommendation(model, scaler, input_data)

                st.success("Here are your crop recommendations:")

                for crop, probability in recommendations:
                    st.markdown(f"""
                        <div class="stat-card">
                            <h3>{crop.title()}</h3>
                            <p>Confidence: {probability:.2%}</p>
                            <p>Best growing conditions:</p>
                            <ul>
                                <li>Temperature: {temperature:.1f}°C</li>
                                <li>Humidity: {humidity:.1f}%</li>
                                <li>pH: {ph:.1f}</li>
                                <li>Rainfall: {rainfall:.1f}mm</li>
                            </ul>
                        </div>
                    """, unsafe_allow_html=True)

                if 'history' not in st.session_state:
                    st.session_state.history = []

                st.session_state.history.append({
                    'input': {
                        'N': nitrogen, 'P': phosphorus, 'K': potassium,
                        'temperature': temperature, 'humidity': humidity,
                        'ph': ph, 'rainfall': rainfall
                    },
                    'recommendations': recommendations
                })

            except Exception as e:
                st.error(f"Error getting recommendation: {str(e)}")
                st.error("Please check your input values and try again.")