import os
import numpy as np
import json
import joblib
from sklearn.ensemble import RandomForestClassifier

MODEL_PATH = "models/plant_disease_model.pkl"
LABELS_PATH = "models/labels.json"

def download_model():
    print("Checking for model...")
    
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    
    if os.path.exists(MODEL_PATH):
        print(f"Model already exists at {MODEL_PATH}")
        return
    
    print("Creating a simple demonstration model...")
    create_demo_model()
    print(f"Demonstration model created at {MODEL_PATH}")

def create_demo_model():
    model = RandomForestClassifier(n_estimators=10, random_state=42)
    
    X_train = np.random.random((100, 500))  
    y_train = np.random.randint(0, 10, 100) 
    model.fit(X_train, y_train)
    
    joblib.dump(model, MODEL_PATH)
    
    labels = [
        "Apple_scab",
        "Black_spot",
        "Tomato_late_blight",
        "Tomato_early_blight",
        "Corn_common_rust",
        "Potato_late_blight",
        "Strawberry_leaf_scorch",
        "Apple_black_rot",
        "Apple_cedar_apple_rust",
        "Healthy",
        "Powdery_Mildew",
        "Downy_Mildew",
        "Leaf_Rust",
        "Stem_Rust",
        "Fusarium_Wilt",
        "Sclerotinia",
        "Leaf_Spot",
        "Seedling_Damping_Off",
        "Bacterial_Wilt",
        "Bacterial_Blight",
        "Fire_Blight",
        "Crown_Gall",
        "Tobacco_Mosaic_Virus",
        "Tomato_Spotted_Wilt_Virus",
        "Tomato_Yellow_Leaf_Curl_Virus",
        "Cucumber_Mosaic_Virus",
        "Potato_Virus_Y",
        "Cauliflower_Mosaic_Virus",
        "African_Cassava_Mosaic_Virus",
        "Plum_Pox_Virus",
        "Brome_Mosaic_Virus",
        "Potato_Virus_X",
        "Healthy"
    ]
    
    with open(LABELS_PATH, 'w') as f:
        json.dump(labels, f)

if __name__ == "__main__":
    download_model()
