import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

def render_visualizations(df):
    st.title("📊 Data Insights")
    
    st.subheader("Parameter Correlations")
    corr_features = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']
    corr_matrix = df[corr_features].corr()
    
    fig_corr = go.Figure(data=go.Heatmap(
        z=corr_matrix,
        x=corr_features,
        y=corr_features,
        colorscale='Blues'  
    ))
    fig_corr.update_layout(title='Parameter Correlation Matrix', height=400)
    st.plotly_chart(fig_corr, use_container_width=True)
    
    st.subheader("Parameter Relationships")
    selected_x_param = st.selectbox(
        "Select X-axis Parameter",
        corr_features
    )
    selected_y_param = st.selectbox(
        "Select Y-axis Parameter",
        corr_features,
        index=1  
    )
    
    if selected_x_param and selected_y_param:
        fig_scatter = px.scatter(
            df,
            x=selected_x_param,
            y=selected_y_param,
            color='label',
            title=f'{selected_x_param.title()} vs {selected_y_param.title()}',
            color_discrete_sequence=px.colors.qualitative.Pastel,  
            height=400
        )
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    st.subheader("Success Rate Analysis")
    param = st.selectbox(
        "Select Environmental Parameter",
        ['temperature', 'humidity', 'ph', 'rainfall']
    )
    
    fig_success = px.histogram(
        df,
        x=param,
        color='Disease_Prone',
        title=f'Success Rate by {param.title()}',
        color_discrete_sequence=['#81C784', '#FFC107'],  
        height=400
    )
    st.plotly_chart(fig_success, use_container_width=True)